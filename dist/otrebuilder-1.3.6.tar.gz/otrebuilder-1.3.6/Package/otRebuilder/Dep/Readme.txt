You can also download all the dependencies your self and put them here.
您也可以手动将所有依赖下载到本地，并放在本目录内。
otRebuilder will search this directory for dependencies first.
otRebuilder 会首先在该目录中查找依赖。
